const db = require('../models');
const bcrypt = require('bcryptjs');
const emailService = require('../services/mailer.service');
const {  Reservation,TotalReservationsCouvertsParJour,Parametre,ReservationsTablesParCreneauJour,Restaurant,Utilisateur,Role,Creneau,Tag,Service,RestaurantTable,Societe,ZoneTable,Notification } = db;
const DEFAULT_PASS = process.env.DEFAULT_PASS;
const notificationService = require('../services/notifications.service');
const { Op } = require('sequelize');
exports.createReservation = async (req, res) => {
  const t = await db.sequelize.transaction();

  try {
    const {
      nom,
      prenom,
      email,
      telephone,
      date_reservation,
      heure_reservation,
      duree_reservation,
      societe_id,
      restaurant_id,
      tags,
      nb_couverts,
      service_id,
      table_id,
      ...rest
    } = req.body;

    const [hD, mD] = heure_reservation.split(':').map(Number);

     //  2. DATE
    const dateObj = new Date(Date.UTC(
      date_reservation.year,
      date_reservation.month - 1,
      date_reservation.day,
      hD,
      mD,
      0
    ));

    
    

    const dateOnly = `${date_reservation.year}-${String(date_reservation.month).padStart(2,'0')}-${String(date_reservation.day).padStart(2,'0')}`;

   
    

     //verifier si existe une reservation pour la table a cette date et annuler avec 400 si oui si non creer
    const existingReservationTablesParCreneauJour = await ReservationsTablesParCreneauJour.findOne({
      where: {
        plage_horaire:`${heure_reservation} ${duree_reservation}`,
        date: dateOnly,
        table_id,
      },
      transaction: t
    });

    // si existe → erreur
    if (existingReservationTablesParCreneauJour) {
      return res.status(400).json({ message: `Table déjà réservée pour ${dateOnly} ${heure_reservation} avec une durée de ${duree_reservation}` });
    }

 

    //  1. CLIENT chercher ou creer
    let client = await Utilisateur.findOne({ where: { email }, transaction: t });

    if (!client) {
      const hashedPassword = await bcrypt.hash(DEFAULT_PASS, 10);

      const role = await Role.findOne({
        where: { type: 'client' },
        transaction: t
      });

      if (!role) {
        throw new Error('Rôle non trouvé');
      }

      client = await Utilisateur.create({
        nom,
        prenom,
        email,
        telephone,
        mot_de_passe: hashedPassword,
        role_id: role.id,
        societe_id,
      }, { transaction: t });

      await client.setRestaurants([restaurant_id], { transaction: t });
    }else{
      await client.addRestaurant(restaurant_id, { transaction: t });
    }


    const service = await Service.findByPk(service_id);

    if (!service) {
      return res.status(404).json({ message: 'Service non trouvé' });
    }

    

    
    //  4. CRÉNEAU DU JOUR (SAFE) chercher ou creer
    const [totalReservationsCouvertsParJour, ] = await TotalReservationsCouvertsParJour.findOrCreate({
      where: {
        service_id:service_id,
        date: dateOnly,
      },
      defaults: {
        service_id:service_id,
        date: dateOnly,
        nb_reservations_actuel: 0,
        nb_couverts_actuel: 0,
        societe_id,
        restaurant_id
      },
      transaction: t
    });

    //  5. CHECK CAPACITÉ (AVANT incrément)
    if (totalReservationsCouvertsParJour.nb_couverts_actuel + nb_couverts >= service.max_couverts_par_service) {
      await t.rollback();
      return res.status(400).json({ message: 'Service complet pour les couverts ' });
    }

    //  6. INCRÉMENT ATOMIQUE
    await totalReservationsCouvertsParJour.increment(
      {
        nb_couverts_actuel: nb_couverts
      },
      {
        transaction: t
      }
    );

    //  7. CRÉATION RÉSERVATION
    const reservation = await Reservation.create({
      ...rest,
      table_id,
      societe_id,
      restaurant_id,
      service_id,
      total_reservations_couverts_par_jour_id: totalReservationsCouvertsParJour.id,
      date_reservation: dateObj,
      client_id: client.id
    }, { transaction: t });


    // sinon créer
    const newReservationTablesParCreneauJour = await ReservationsTablesParCreneauJour.create({
      creneau_id,
      date: dateOnly,
      table_id,
      societe_id,
      reservation_id:reservation.id,
      restaurant_id,
      utilisateur_id: client.id
    }, { transaction: t });

    //  8. TAGS
    if (tags?.length) {
      await reservation.setTags(tags, { transaction: t });
    }

    //  9. table

    const table = await RestaurantTable.findByPk(table_id);

    if (!table) {
      return res.status(404).json({
        message: 'Table non trouvée'
      });
    }

    if (table.statut=="réservée") {
      await t.rollback();
      return res.status(400).json({ message: 'Table déja réservée' });
    }

   

    const dateReservation = new Date(reservation.date_reservation).toLocaleString('fr-FR', {
      timeZone: 'UTC',
    });

    await notificationService.createNotification({
        objet:reservation,
        titre: `Nouvelle reservation`,
        type:'info',
        texte: `Vous avez une nouvelle réservation ${reservation.id} : Client "${prenom} ${nom}" pour le "${dateReservation}" dans le restaurant ${restaurant_id}`,
    });

    await notificationService.createNotification({
         objet:reservation,
        titre: `Nouvelle reservation`,
        type:'rappel',
        texte: `N'oubliez pas votre réservation ${reservation.id} pour ${dateReservation}`,
        utilisateur_id: reservation.client_id
    });

  
    
    
         
    await t.commit();


    //  9. RELOAD (hors transaction → plus rapide)
    const reservationObjet = await Reservation.findByPk(reservation.id, {
      include: [
        { association: 'client' },
        { association: 'table',
          include: [
            { model: ZoneTable }
          ]
        },
        { association: 'service' },
        { association: 'creneau' },
        { association: 'societe' },
        { association: 'tags' },
      ]
    });


      // chercher le paramètre d'envoi mail
const params = await Parametre.findOne({
  where: {
    restaurant_id: restaurant_id,
    type: 'envoi_de_mail_recap_reservation',
    est_actif: true
  }
});
 
console.log("EMAIL PARAM CHECK =", params);

// si activation email OK
if (params) {
  try {
    const restaurant = await Restaurant.findByPk(restaurant_id);

    const nom_restaurant = restaurant?.nom || '';
    const telephone_restaurant = restaurant?.telephone || '';

    const titre = 'Récapitulatif de votre réservation';

    const dateReservation = new Date(reservation.date_reservation).toLocaleString('fr-FR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    const dateCreation = new Date(reservation.created_at).toLocaleString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

    await emailService.sendMail({
      to: email,
      subject: titre,
      template: 'recap-reservation.ejs',
      context: {
        titre,
        nom,
        prenom,
        email,
        nom_restaurant,
        telephone_restaurant,
        date_reservation: dateReservation,
        date_creation: dateCreation,
        nombre_personnes: reservation.nombre_de_personnes,
        nombre_couverts: reservation.nb_couverts,
        table: table?.titre || table?.nom || `Table ${table_id}`,
        creneau: creneau ? `${creneau.heure_debut} - ${creneau.heure_fin}` : '',
        demandes_speciales: reservationObjet.tags ?.map(tag => tag.titre).join(', ') || '',
        commentaire: reservation.notes
      }
    });

  } catch (err) {
    console.error("Erreur email (non bloquante):", err);
  }
}

   
    res.json(reservationObjet);

  } catch (error) {
    await t.rollback();
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.getReservations = async (req, res) => {
  try {

  
    const selectedRestaurantId = req.query.restaurant_id;
    let restaurantFilter = {};

    let ishigh = req.role_priorite<4

    if (!ishigh) {
        if(req.role_priorite==8){
          restaurantFilter = {societe_id: req.societe_id,client_id:req.user_id}
        }
        else if (selectedRestaurantId) {
          //  filtre sur UN restaurant
          restaurantFilter = {
              restaurant_id: selectedRestaurantId,
              societe_id: req.societe_id
          };
        } else {
          //  filtre sur plusieurs restaurants autorisés
          restaurantFilter = {
              restaurant_id: {
              [Op.in]: req.restos
              },
              societe_id: req.societe_id
          };
        }
    }else{
        if (req.isSuperAdmin) {
        restaurantFilter = {}
        }else{
            restaurantFilter = {societe_id: req.societe_id}
        }
    }
    const where = {};

    if (req.query.restaurant_id) {
      where.restaurant_id = req.query.restaurant_id;
    }
    

    const reservations = await Reservation.findAll({
      where:restaurantFilter,
      include: [
        {
            model: Restaurant,
            attributes: ['id', 'nom', 'coordonnees_google_maps', 'ville', 'adresse', 'heure_debut', 'heure_fin', 'telephone'],
            required: false,
        },
        { association: 'client' },
        { association: 'table' },
        { association: 'service' },
        { association: 'creneau' },
        { association: 'societe' },
        { association: 'paiements' },
        { association: 'tags' }
      ],
      order: [['date_reservation', 'DESC']]
    });

    res.json(reservations);
  } catch (error) {
    console.log(error)
    res.status(500).json({ message: error.message });
  }
};

exports.getMaxReservations = async (req, res) => {
  try {

  
    const selectedRestaurantId = req.query.restaurant_id;
    let restaurantFilter = {};

    let ishigh = req.role_priorite<4

    if (!ishigh) {
        if(req.role_priorite==8){
          restaurantFilter = {societe_id: req.societe_id,client_id:req.user_id}
        }
        else if (selectedRestaurantId) {
          //  filtre sur UN restaurant
          restaurantFilter = {
              restaurant_id: selectedRestaurantId,
              societe_id: req.societe_id
          };
        } else {
          //  filtre sur plusieurs restaurants autorisés
          restaurantFilter = {
              restaurant_id: {
              [Op.in]: req.restos
              },
              societe_id: req.societe_id
          };
        }
    }else{
        if (req.isSuperAdmin) {
        restaurantFilter = {}
        }else{
            restaurantFilter = {societe_id: req.societe_id}
        }
    }
    const where = {};

    if (req.query.restaurant_id) {
      where.restaurant_id = req.query.restaurant_id;
    }
    

    const reservations = await Reservation.findAll({
      where:restaurantFilter,
      include: [
        {
            model: Restaurant,
            attributes: ['id', 'nom', 'coordonnees_google_maps', 'ville', 'adresse', 'heure_debut', 'heure_fin', 'telephone'],
            required: false,
        },
        { association: 'client' },
        { association: 'table' },
        { association: 'service' },
        { association: 'creneau' },
        { association: 'societe' },
        { association: 'paiements' },
        { association: 'tags' },
      ],
      order: [['date_reservation', 'DESC']],
      limit: 4
    });

    res.json(reservations);
  } catch (error) {
    console.log(error)
    res.status(500).json({ message: error.message });
  }
};

exports.getReservationById = async (req, res) => {
  try {
    const reservation = await Reservation.findByPk(req.params.id, {
      include: [
        {
            model: Restaurant,
            attributes: ['id', 'nom', 'coordonnees_google_maps', 'ville', 'adresse', 'heure_debut', 'heure_fin', 'telephone'],
            required: false,
        },
        { association: 'client' },
        { association: 'table' },
        { association: 'service' },
        { association: 'creneau' },
        { association: 'societe' },
        { association: 'paiements' },
        { association: 'tags' },
      ],
    });

    if (!reservation) {
      return res.status(404).json({ message: 'Reservation non trouvé' });
    }

    res.json(reservation);
  } catch (error) {
    console.log(error.message)
    res.status(500).json({ message: error.message });
  }
};

exports.updateReservation = async (req, res) => {
  const t = await db.sequelize.transaction();

  try {
    const reservation = await Reservation.findByPk(req.params.id, {
      transaction: t,
      lock: t.LOCK.UPDATE //  important
    });

    if (!reservation) {
      await t.rollback();
      return res.status(404).json({ message: 'Reservation non trouvée' });
    }

    const former_statut = reservation.statut;

    const {
      date_reservation,
      heure_reservation,
      statut,
      total_reservations_creneau_par_jour_id,
      creneau_id,
      table_id,
      societe_id,
      restaurant_id,
      tags,
      ...rest
    } = req.body;
    

    //  Convert date
    const dateObj = new Date(Date.UTC(
      date_reservation.year,
      date_reservation.month - 1,
      date_reservation.day,
      heure_reservation.hour,
      heure_reservation.minute,
      heure_reservation.second || 0
    ));

    const dateOnly = `${date_reservation.year}-${String(date_reservation.month).padStart(2,'0')}-${String(date_reservation.day).padStart(2,'0')}`;


    //  Récupérer créneau
    const creneau = await Creneau.findByPk(creneau_id, { transaction: t });
    if (!creneau) throw new Error('Créneau introuvable');

    //  Charger créneau du jour avec lock ne change jamais
     TotalReservationsCouvertsParJour = await TotalReservationsCouvertsParJour.findByPk(total_reservations_creneau_par_jour_id, {
      transaction: t,
      lock: t.LOCK.UPDATE
    });

    //cet objet compte le nombre de reservations pour un creneau, donc verifier que le creneau n'a pa change si il change decrementer ceci et creer un autre a lier
    if (TotalReservationsCouvertsParJour.creneau_id !== creneau_id) {

      // 1. décrémenter ancien créneau (sécurisé)
      if (TotalReservationsCouvertsParJour.nb_reservations_actuel > 0) {
        await TotalReservationsCouvertsParJour.increment('nb_reservations_actuel', {
          by: -1,
          transaction: t
        });
      }

      // 2. créer ou récupérer le nouveau créneau
      const [newCreneau, created] = await TotalReservationsCouvertsParJour.findOrCreate({
        where: {
          creneau_id,
          date: dateOnly,
        },
        defaults: {
          creneau_id,
          date: dateOnly,
          nb_reservations_actuel: 0,
          societe_id:reservation.societe_id,
          restaurant_id:reservation.restaurant_id
        },
        transaction: t
      });

      // 3. incrémenter le nouveau
      await newCreneau.increment('nb_reservations_actuel', {
        by: 1,
        transaction: t
      });

      TotalReservationsCouvertsParJour = newCreneau;
    }


    if (!TotalReservationsCouvertsParJour) {
      throw new Error('Créneau du jour introuvable');
    }

    //  Définir groupes de statuts
    const actifs = ['En attente', 'Confirmée','En cours'];
    const inactifs = ['Annulée','Terminée','No-show'];

    let delta = 0;

    const table = await RestaurantTable.findByPk(table_id);
    if (!table) {
      return res.status(404).json({
        message: 'Table non trouvée'
      });
    }

    //   decrementer le nombre de reservations pour table, creneau, date correspondant
    if (actifs.includes(former_statut) && inactifs.includes(statut)) {
      delta = -1;

      //  supprimer
      const reservationsTablesParCreneauJour = await ReservationsTablesParCreneauJour.findOne({
        where: {
          reservation_id: reservation.id,
        }}, 
        { transaction: t }
      );

      if (reservationsTablesParCreneauJour) {
        await reservationsTablesParCreneauJour.destroy({ transaction: t });
      }

    } else if (inactifs.includes(former_statut) && actifs.includes(statut)) {
      // incrementer le nombre de reservations pour table, creneau, date correspondant
      delta = +1;

      //cet objet compte les reservations pour une table a une date et un creneau il permet de ne pas reservaer la meme table 2 fois a des creneaux differents donc verifier si il existe une objet pour cette reservation  si oui checker que c'est la meme table le meme creneau et la meme date si non creer un nouvel objet et supprimer le précédent
      const existing = await ReservationsTablesParCreneauJour.findOne({
        where: { reservation_id: reservation.id },
        transaction: t
      });

      const isSame =
        existing &&
        existing.table_id === reservation.table_id &&
        existing.creneau_id === reservation.creneau_id &&
        existing.date === date_reservation;
      if (!existing || !isSame) {

        if (existing) {//si existe et different il le supprime
          await existing.destroy({ transaction: t });
        }

        await ReservationsTablesParCreneauJour.create({
          creneau_id: creneau_id,
          date: date_reservation,
          table_id: table_id,
          societe_id: societe_id,
          reservation_id: reservation.id,
          restaurant_id: reservation.restaurant_id,
          utilisateur_id: reservation.client_id,
        }, { transaction: t });
      }
    }else{//si statut ne change pas

      //cet objet compte les reservations pour une table a une date et un creneau il permet de ne pas reservaer la meme table 2 fois a des creneaux differents donc verifier si il existe une objet pour cette reservation  si oui checker que c'est la meme table le meme creneau et la meme date si non creer un nouvel objet et supprimer le précédent
      const existing = await ReservationsTablesParCreneauJour.findOne({
        where: { reservation_id: reservation.id },
        transaction: t
      });

      const isSame =
        existing &&
        existing.table_id === reservation.table_id &&
        existing.creneau_id === reservation.creneau_id &&
        existing.date === date_reservation;
      if (!existing || !isSame) {

        if (existing) {//si existe et different il le supprime
          await existing.destroy({ transaction: t });
        }

        await ReservationsTablesParCreneauJour.create({
          creneau_id: creneau_id,
          date: date_reservation,
          table_id: table_id,
          societe_id: reservation.societe_id,
          reservation_id: reservation.id,
          restaurant_id: reservation.restaurant_id,
          utilisateur_id: reservation.client_id,
        }, { transaction: t });
      }

    }

    //  Appliquer delta
    if (delta !== 0) {
      if (delta === 1 && TotalReservationsCouvertsParJour.nb_reservations_actuel >= creneau.nb_reservations_max) {
        await t.rollback();
        return res.status(400).json({ message: 'Créneau complet' });
      }

      if (delta === -1 && TotalReservationsCouvertsParJour.nb_reservations_actuel <= 0) {
        await t.rollback();
        return res.status(400).json({ message: 'Compteur invalide' });
      }

      await TotalReservationsCouvertsParJour.increment('nb_reservations_actuel', {
        by: delta,
        transaction: t
      });
    }

    //  UPDATE UNIQUE
    await reservation.update({
      ...rest,
      statut,
      table_id,
      creneau_id,
      date_reservation: dateObj
    }, { transaction: t });

    //  TAGS
    if (tags?.length) {
      await reservation.setTags(tags, { transaction: t });
    }

    await t.commit();

    //  Reload
    const reservationUpdated = await Reservation.findByPk(reservation.id, {
      include: [
        { association: 'client' },
        { association: 'table' },
        { association: 'service' },
        { association: 'creneau' },
        { association: 'societe' },
        { association: 'tags' }
      ]
    });

    res.json(reservationUpdated);

  } catch (error) {
    await t.rollback();
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.deleteReservation = async (req, res) => {
  const t = await db.sequelize.transaction();

  try {
    const reservation = await Reservation.findByPk(req.params.id, { transaction: t });

    if (!reservation) {
      await t.rollback();
      return res.status(404).json({ message: 'Reservation non trouvée' });
    }

    const TotalReservationsCouvertsParJour = await TotalReservationsCouvertsParJour.findByPk(
      reservation.total_reservations_creneau_par_jour_id,
      { transaction: t }
    );

    if (TotalReservationsCouvertsParJour && TotalReservationsCouvertsParJour.nb_reservations_actuel > 0) {
      await TotalReservationsCouvertsParJour.increment('nb_reservations_actuel', {
        by: -1,
        transaction: t
      });
    }

    const reservationsTablesParCreneauJour = await ReservationsTablesParCreneauJour.findOne({
      where: {
        reservation_id: reservation.id,
      }}, 
      { transaction: t }
    );

    if (reservationsTablesParCreneauJour) {
      await reservationsTablesParCreneauJour.destroy({ transaction: t });
    }

    

    await reservation.destroy({ transaction: t });

    await t.commit();

    return res.json({ message: 'Reservation supprimée' });

  } catch (error) {
    await t.rollback();
    return res.status(500).json({ message: error.message });
  }
};


exports.getReservationDatasBySocieteID = async (req, res) => {
  try {

    const societeID = req.params.societeID;

    const societe = await Societe.findByPk(societeID);

    if (!societe) {
      return res.status(404).json({
        message: 'Societe non trouvée'
      });
    }
    restaurantFilter = {societe_id: societeID};


    const tags = await Tag.findAll({where: restaurantFilter,});
    const services = await Service.findAll({where: restaurantFilter,});
    const creneaux = await Creneau.findAll({where: restaurantFilter,});
    const tables = await RestaurantTable.findAll({
        where: {
        ...restaurantFilter,
          statut: 'libre'
        },
        include: [
          {
            model: ZoneTable,
            attributes: ['id', 'titre',  ],
            required: false,
          }
        ],
        order: [['zone_id', 'ASC']]
      },
    );
    const restaurants = await Restaurant.findAll({
      where: restaurantFilter,
      include: [
        {
          association: 'parametres',
          where: { est_important: true },
          required: false
        },
        {
          association: 'horaires',
          include: [
            {
                model: Service,
                required: false,
            }
          ],
        },
      ],
      order: [['created_at', 'DESC']]
    });
    

    res.json({
      societe:societe,
      tags:tags,
      services:services,
      creneaux:creneaux,
      tables:tables,
      restaurants:restaurants,

    });
  } catch (error) {
    console.log(error.message)
    res.status(500).json({ message: error.message });
  }
};