const db = require('../models');
const {  Livraison,Societe,Restaurant,Utilisateur,Commande } = db;
const { Op } = require('sequelize');
const notificationService = require('../services/notifications.service');
exports.createLivraison = async (req, res) => {
  try {

    const {
      date_livraison,
      heure_livraison,
      ...rest
    } = req.body;

     //  2. DATE
    const dateObj = new Date(Date.UTC(
      date_livraison.year,
      date_livraison.month - 1,
      date_livraison.day,
      heure_livraison.hour,
      heure_livraison.minute,
      heure_livraison.second || 0
    ));
    const livraison = await Livraison.create({
      ...rest,
      date_livraison: dateObj,
    });

    //  9. RELOAD (hors transaction → plus rapide)
    const livraisonObjet = await Livraison.findByPk(livraison.id, {
      include: [
        { association: 'client' },
        { association: 'livreur' },
      ]
    });

    const dateLivraison = new Date(livraisonObjet.date_livraison).toLocaleString('fr-FR');

    
    await notificationService.createNotification({
      objet:livraisonObjet,
      titre: `Nouvelle livraison`,
      type:'info',
      texte: `Vous avez une nouvelle livraison ${livraisonObjet.id} : Client "${livraisonObjet.client.prenom} ${livraisonObjet.client.nom}" livreur "${livraisonObjet.livreur.prenom} ${livraisonObjet.livreur.nom}" pour le "${dateLivraison}" dans le restaurant ${livraisonObjet.restaurant_id}`,
    });

    await notificationService.createNotification({
      objet:livraisonObjet,
      titre: `Nouvelle livraison`,
      type:'rappel',
      texte: `N'oubliez pas votre livraison ${livraisonObjet.id} pour ${dateLivraison}`,
      utilisateur_id: livraisonObjet.client_id
    });
    if(livraisonObjet.livreur_id){
      const d = new Date(livraisonObjet.date_livraison);

      const formattedDate =
        d.toLocaleDateString('fr-FR') + ' ' +
        d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

      await notificationService.createNotification({
        objet:livraisonObjet,
        titre: `Nouvelle livraison`,
        type:'rappel',
        texte: `Vous avez une livraison ${livraisonObjet.id} prévue le ${formattedDate} pour le client "${livraisonObjet.client.prenom} ${livraisonObjet.client.nom}"`,
        utilisateur_id: livraisonObjet.livreur_id
      });
    }

    
    res.json(livraisonObjet);
  } catch (error) {
    console.log(error)
    res.status(500).json({ message: error.message });
  }
};

exports.getLivraisons = async (req, res) => {
  try {
    const selectedRestaurantId = req.query.restaurant_id;
    let restaurantFilter = {};

    let ishigh = req.role_priorite<4

    if (!ishigh) {
        if (selectedRestaurantId) {
          //  filtre sur UN restaurant
          restaurantFilter = {
              restaurant_id: selectedRestaurantId,
              societe_id: req.societe_id
          };
        }
        else if (req.role_priorite==8) {//client
          restaurantFilter = {societe_id: req.societe_id,client_id:req.user_id}
          console.log(req.user_id)
          console.log(req.role_priorite)
          console.log(req.societe_id)
        }
        else if (req.role_priorite==9) {//livreur
          restaurantFilter = {societe_id: req.societe_id,livreur_id:req.user_id}
        }
        else {
          //  filtre sur plusieurs restaurants autorisés
          restaurantFilter = {
              restaurant_id: {
              [Op.in]: req.restos
              },
              societe_id: req.societe_id
          };
        }
    }else{
        if (req.isSuperAdmin) {
        restaurantFilter = {}
        }
        
        else{
        restaurantFilter = {societe_id: req.societe_id}
        }
    }
    const where = {};

    if (req.query.restaurant_id) {
      where.restaurant_id = req.query.restaurant_id;
    }
    

    const livraisons = await Livraison.findAll({
         where:restaurantFilter,
          include: [
            {
                model: Restaurant,
                attributes: ['id', 'nom', 'coordonnees_google_maps', 'ville', 'adresse', 'heure_debut', 'heure_fin', 'telephone'],
                required: false,
            },
            {
                model: Societe,
                attributes: ['id', 'titre', ],
                as: 'societe',
                required: false,
            },
            {
              model: Utilisateur,
              as: 'client',
              required: false
            },
            {
              model: Utilisateur,
              as: 'livreur',
              required: false
            },
            {
              model: Commande,
              as: 'commande',
              required: false
            },
        ],

    }
);

    res.json(livraisons);
  } catch (error) {
    console.log(error)
    res.status(500).json({ message: error.message });
  }
};



exports.getLivraisonsByUserId = async (req, res) => {
  try {
     const userID = req.params.userID;
     const priorite =req.role_priorite
     const societe_id =req.societe_id

     console.log(userID,priorite,societe_id)
      if(req.role_priorite<8 && req.role_priorite>2){// 3 a 7
        userFilter = {societe_id: societe_id}
      }else if(req.role_priorite==9){
        userFilter = {societe_id: societe_id,livreur_id:userID}
      }
    
    

    const livraisons = await Livraison.findAll({
         where:userFilter,
          include: [
            {
                model: Restaurant,
                attributes: ['id', 'nom', 'coordonnees_google_maps', 'ville', 'adresse', 'heure_debut', 'heure_fin', 'telephone'],
                required: false,
            },
            {
              model: Utilisateur,
              as: 'client',
              required: false
            },
            {
              model: Utilisateur,
              as: 'livreur',
              required: false
            },
            {
              model: Commande,
              as: 'commande',
              required: false
            },
        ],

    });

    livraisons.forEach(cmd => {
      if (typeof cmd.commande.items === 'string') {
        cmd.commande.items = JSON.parse(cmd.commande.items);
      }
    });

    res.json(livraisons);
  } catch (error) {
    console.log(error)
    res.status(500).json({ message: error.message });
  }
};

exports.getLivraisonById = async (req, res) => {
  try {
    const livraison = await Livraison.findByPk(req.params.id);

    if (!livraison) {
      return res.status(404).json({ message: 'Livraison non trouvé' });
    }

    res.json(livraison);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateLivraison = async (req, res) => {
  try {

     const {
      date_livraison,
      heure_livraison,
      ...rest
    } = req.body;

     //  2. DATE
    const dateObj = new Date(Date.UTC(
      date_livraison.year,
      date_livraison.month - 1,
      date_livraison.day,
      heure_livraison.hour,
      heure_livraison.minute,
      heure_livraison.second || 0
    ));
    const livraison = await Livraison.findByPk(req.params.id);

    if (!livraison) {
      return res.status(404).json({ message: 'Livraison non trouvé' });
    }

    await livraison.update(
      {
        date_livraison:dateObj,
        
        ...rest
      }
    );

    if(livraison.client_id){
      const livraisonObjet = await Livraison.findByPk(livraison.id, {
        include: [
          { association: 'client' },
          { association: 'livreur' },
        ]
      });

      const d = new Date(livraisonObjet.date_livraison);

      const formattedDate =
        d.toLocaleDateString('fr-FR') + ' ' +
        d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

      await notificationService.createNotification({
        objet:livraisonObjet,
        titre: `Nouvelle livraison`,
        type:'rappel',
        texte: `Vous avez une livraison ${livraisonObjet.id} prévue le ${formattedDate} pour le client "${livraisonObjet.client.prenom} ${livraisonObjet.client.nom}"`,
        utilisateur_id: livraisonObjet.livreur_id
      });

    }

    

    res.json(livraison);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


exports.updatestatutLivraison = async (req, res) => {
  try {

     const {
      statut
    } = req.body;

    const actifs = ['En attente','En cours'];
    const inactifs = ['Annulée'];

    const livraison = await Livraison.findByPk(req.params.id);
    const commande = await Commande.findByPk(livraison.commande_id);
    const former_statut = livraison.statut;

    if (!livraison) {
      return res.status(404).json({ message: 'Livraison non trouvé' });
    }
    if (!commande) {
      return res.status(404).json({ message: 'Livraison non trouvé' });
    }

    if (actifs.includes(former_statut) && (statut)=='Terminée') {
      await livraison.update({ statut:statut,});
      await commande.update({ statut:'Retirée',});
    }else if (actifs.includes(former_statut) && (statut)=='Annulée') {
      await livraison.update({ statut:statut,});
      await commande.update({ statut:'Annulée',});
    }
    else if (inactifs.includes(former_statut) && actifs.includes(statut)) {
      await livraison.update({ statut:statut,});
      await commande.update({ statut:'Prête',});
    }

  

    res.json(livraison);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.deleteLivraison = async (req, res) => {
  try {
    const livraison = await Livraison.findByPk(req.params.id);

    if (!livraison) {
      return res.status(404).json({ message: 'Livraison non trouvé' });
    }

    await livraison.destroy();

    res.json({ message: 'Livraison supprimé' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};