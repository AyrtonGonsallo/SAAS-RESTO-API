const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
    process.env.DB_NAME,
    process.env.DB_USER,
    process.env.DB_PASSWORD,
    {
        host: process.env.DB_HOST,
        dialect: 'mysql',
        logging: false,
        timezone: '+00:00', //  force écriture en UTC

        dialectOptions: {
        useUTC: true, //  lecture en UTC
        dateStrings: true, // optionnel (évite conversion auto)
        typeCast: true
        }
    }
);

const connectDB = async () => {
    try {
        await sequelize.authenticate();
        console.log('✅ Connexion DB OK');
    } catch (error) {
        console.error('❌ Erreur connexion DB:', error.message);
        process.exit(1);
    }
};

module.exports = {
    sequelize,
    connectDB
};